package com.example.linxhoursofoperation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EdHallCafe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ed_hall_cafe);
    }
}